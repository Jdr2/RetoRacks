import { Redirect, Router } from 'react-router-dom';
import React from 'react';

const PrivateRouter = () => {
    // Check if our user is authenticated
    const isAuthenticated = false;

    // If the user is not authenticated, redirect to the sign in page
    return isAuthenticated? <Router /> : <Redirect to="/iniciar-sesion" />;
}

export default PrivateRouter;
