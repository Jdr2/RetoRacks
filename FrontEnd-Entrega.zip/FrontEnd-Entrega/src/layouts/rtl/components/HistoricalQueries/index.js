import React, { useState } from "react";
// @mui material components
import Card from "@mui/material/Card";
import Button from "@mui/material/Button";

//  Dashboard React components
import VuiBox from "components/VuiBox";
import VuiTypography from "components/VuiTypography";

// Billing page components
import Transaction from "layouts/billing/components/Transaction";

function HistoricalQueries() {
  const [results, setResults] = useState([]);
  const [history, setHistory] = useState([]);

  const handleSearch = (query) => {
    // Aquí puedes agregar la lógica para buscar consultas históricas
    // Por ahora, vamos a simular algunos resultados
    const newResults = [
      {
        color: "error",
        icon: "arrow_downward",
        name: "Netflix",
        description: "27 March 2020, at 12:30 PM",
        value: "- $ 2,500",
      },
      {
        color: "success",
        icon: "arrow_upward",
        name: "Apple",
        description: "27 March 2020, at 04:30 AM",
        value: "+ $ 2,000",
      },
    ];

    setResults(newResults);
    setHistory([...history, query]);
  };

  return (
    <Card sx={{ height: "100%" }}>
      <VuiBox
        display="flex"
        flexDirection="column"
        justifyContent="space-between"
        alignItems="center"
        mb="18px"
        sx={({ breakpoints }) => ({
          [breakpoints.down("lg")]: {
            flexDirection: "column",
          },
        })}
      >
        <VuiTypography
          variant="lg"
          fontWeight="bold"
          textTransform="capitalize"
          color="white"
          sx={({ breakpoints }) => ({
            [breakpoints.only("sm")]: {
              mb: "6px",
            },
          })}
        >
          Búsqueda de Consultas Históricas
        </VuiTypography>
      </VuiBox>
      <VuiBox width="100%">
        <VuiBox mb={2}>
          <Button variant="contained" color="primary" onClick={() => handleSearch("Inventarios del mes actual")}>
            Inventarios del mes actual
          </Button>
        </VuiBox>
        <VuiBox mb={2}>
          <Button variant="contained" color="primary" onClick={() => handleSearch("Inventarios del día de hoy")}>
            Inventarios del día de hoy
          </Button>
        </VuiBox>
        <VuiBox mb={2}>
          <Button variant="contained" color="primary" onClick={() => handleSearch("Inventarios de la semana")}>
            Inventarios de la semana
          </Button>
        </VuiBox>
        {history.length > 0 && (
          <>
            <VuiBox mb={2}>
              <VuiTypography
                variant="caption"
                color="text"
                fontWeight="medium"
                textTransform="uppercase"
              >
                Historial de Búsquedas
              </VuiTypography>
            </VuiBox>
            <VuiBox
              component="ul"
              display="flex"
              flexDirection="column"
              p={0}
              m={0}
              sx={{ listStyle: "none" }}
            >
              {history.map((item, index) => (
                <VuiBox component="li" key={index} mb={1}>
                  <VuiTypography variant="body2" color="text">
                    {item}
                  </VuiTypography>
                </VuiBox>
              ))}
            </VuiBox>
          </>
        )}
        {results.length > 0 && (
          <>
            <VuiBox mb={2}>
              <VuiTypography
                variant="caption"
                color="text"
                fontWeight="medium"
                textTransform="uppercase"
              >
                Resultados
              </VuiTypography>
            </VuiBox>
            <VuiBox
              component="ul"
              display="flex"
              flexDirection="column"
              p={0}
              m={0}
              sx={{ listStyle: "none" }}
            >
              {results.map((result, index) => (
                <Transaction
                  key={index}
                  color={result.color}
                  icon={result.icon}
                  name={result.name}
                  description={result.description}
                  value={result.value}
                />
              ))}
            </VuiBox>
          </>
        )}
      </VuiBox>
    </Card>
  );
}

export default HistoricalQueries;