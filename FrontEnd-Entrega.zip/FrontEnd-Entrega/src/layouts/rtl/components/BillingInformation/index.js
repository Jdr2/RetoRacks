import { useState } from "react";
import { createInOut } from "services/createInOut/createInOut";
// @mui material components
import Card from "@mui/material/Card";
import Button from "@mui/material/Button";
import MenuItem from "@mui/material/MenuItem";
import Select from "@mui/material/Select";
import TextField from "@mui/material/TextField";

//  Dashboard React components
import VuiBox from "components/VuiBox";
import VuiTypography from "components/VuiTypography";

function CreateInOutForm() {
  const [formData, setFormData] = useState({
    instalacion: "",
    ubicacion: "",
    transaccion: "",
    codigo_articulo: "",
    descripcion_articulo: "",
    cantidad: 0,
    usuario: ""
  });

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormData({ 
      ...formData, 
      [name]: name === "cantidad" ? Number(value) : value 
    });
  };

  const handleSubmit = async () => {
    const data = {
      ...formData,
      id: 7, // Puedes generar un ID único si es necesario
      fecha_hora: new Date().toISOString()
    };
    console.log("Datos enviados:", JSON.stringify(data, null, 2)); // Imprime el JSON en consola
    try {
      await createInOut(data);
      alert("Entrada de almacén creada exitosamente");
    } catch (error) {
      console.error("Error al crear la entrada de almacén:", error);
    }
  };

  return (
    <Card id="create-inout">
      <VuiBox p={3}>
        <VuiTypography variant="lg" color="white" fontWeight="bold" mb={2}>
          Crear Entrada de Almacén
        </VuiTypography>
        <VuiBox component="form" display="flex" flexDirection="column" gap={2}>
          <Select
            name="instalacion"
            value={formData.instalacion}
            onChange={handleChange}
            displayEmpty
          >
            <MenuItem value="" disabled>Selecciona Instalación</MenuItem>
            <MenuItem value="Barcel">Barcel</MenuItem>
            <MenuItem value="OtraInstalacion">Otra Instalación</MenuItem>
          </Select>
          <Select
            name="ubicacion"
            value={formData.ubicacion}
            onChange={handleChange}
            displayEmpty
          >
            <MenuItem value="" disabled>Selecciona Ubicación</MenuItem>
            <MenuItem value="A11">A11</MenuItem>
            <MenuItem value="B22">B22</MenuItem>
          </Select>
          <Select
            name="transaccion"
            value={formData.transaccion}
            onChange={handleChange}
            displayEmpty
          >
            <MenuItem value="" disabled>Selecciona Transacción</MenuItem>
            <MenuItem value="ING">Ingreso (ING)</MenuItem>
            <MenuItem value="RET">Retiro (RET)</MenuItem>
          </Select>
          <Select
            name="codigo_articulo"
            value={formData.codigo_articulo}
            onChange={handleChange}
            displayEmpty
          >
            <MenuItem value="" disabled>Selecciona código de artículo</MenuItem>
            <MenuItem value="papas-01">papas-01</MenuItem>
            <MenuItem value="papas-02">papas-02</MenuItem>
          </Select>
          <Select
            name="descripcion_articulo"
            value={formData.descripcion_articulo}
            onChange={handleChange}
            displayEmpty
          >
            <MenuItem value="" disabled>Selecciona Descripción</MenuItem>
            <MenuItem value="Papas Chips Jalapeno 250">Papas Chips Jalapeno 250</MenuItem>
            <MenuItem value="Papas Chips Original 500">Papas Chips Original 500</MenuItem>
          </Select>
          <TextField
            name="cantidad"
            label="Cantidad"
            type="number"
            value={formData.cantidad}
            onChange={handleChange}
          />
          <TextField
            name="usuario"
            label="Usuario"
            value={formData.usuario}
            onChange={handleChange}
          />
          <Button variant="contained" color="primary" onClick={handleSubmit}>
            Crear Entrada
          </Button>
        </VuiBox>
      </VuiBox>
    </Card>
  );
}

export default CreateInOutForm;