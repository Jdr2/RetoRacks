import { useAuth } from 'context/AuthContext';
import { Redirect } from 'react-router-dom';
import React, { useState } from 'react';

function CameraCapture() {
  const [image, setImage] = useState(null);
  const [videoStream, setVideoStream] = useState(null);
  const { isAuthenticated } = useAuth();

  // console.log('isAuthenticated codebar:', isAuthenticated);

  if (!isAuthenticated) {
    return <Redirect to="/iniciar-sesion" />;
  }





  return (
    <div style={{ marginLeft: '9cm', marginTop: '3cm' }}>
   
      {/* iframe de Roboflow con el modelo actualizado */}
      <div style={{ marginTop: '20px' }}>
        <iframe
          height="1600"
          style={{ width: '80%' }}
          scrolling="no"
          title="Roboflow Inference"
          src="https://detect.roboflow.com/?model=carboard-box&version=4&api_key=CZvjM1aEqqFXXc60Q7Kx"
          frameBorder="no"
          loading="lazy"
          allowTransparency="true"
          allowFullScreen="true"
        >
          See the Pen <a href="https://codepen.io/roboflow/pen/VwaKXdM">Roboflow Inference Example</a> by Roboflow
          (<a href="https://codepen.io/roboflow">@roboflow</a>) on <a href="https://codepen.io">CodePen</a>.
        </iframe>
      </div>
    </div>
  );
}

export default CameraCapture;
