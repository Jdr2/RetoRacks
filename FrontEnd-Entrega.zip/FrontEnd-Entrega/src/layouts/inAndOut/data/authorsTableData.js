/*
//  Dashboard React components
import VuiBox from "components/VuiBox";
import VuiTypography from "components/VuiTypography";
import VuiAvatar from "components/VuiAvatar";
import VuiBadge from "components/VuiBadge";

// Images
import avatar1 from "assets/images/avatar1.png";
import avatar2 from "assets/images/avatar2.png";
import avatar3 from "assets/images/avatar3.png";
import avatar4 from "assets/images/avatar4.png";
import avatar5 from "assets/images/avatar5.png";
import avatar6 from "assets/images/avatar6.png";

function Author({ image, name, email }) {
  return (
    <VuiBox display="flex" alignItems="center" px={1} py={0.5}>
      <VuiBox mr={2}>
        <VuiAvatar src={image} alt={name} size="sm" variant="rounded" />
      </VuiBox>
      <VuiBox display="flex" flexDirection="column">
        <VuiTypography variant="button" color="white" fontWeight="medium">
          {name}
        </VuiTypography>
        <VuiTypography variant="caption" color="text">
          {email}
        </VuiTypography>
      </VuiBox>
    </VuiBox>
  );
}

function Function({ job, org }) {
  return (
    <VuiBox display="flex" flexDirection="column">
      <VuiTypography variant="caption" fontWeight="medium" color="white">
        {job}
      </VuiTypography>
      <VuiTypography variant="caption" color="text">
        {org}
      </VuiTypography>
    </VuiBox>
  );
}

export default {
  columns: [
    { name: "author", align: "left" },
    { name: "function", align: "left" },
    { name: "status", align: "center" },
    { name: "employed", align: "center" },
    { name: "action", align: "center" },
  ],
  rows: [
    {
      author: <Author image={avatar4} name="Esthera Jackson" email="esthera@simmmple.com" />,
      function: <Function job="Manager" org="Organization" />,
      status: (
        <VuiBadge
          variant="standard"
          badgeContent="Online"
          color="success"
          size="xs"
          container
          sx={({ palette: { white, success }, borders: { borderRadius, borderWidth } }) => ({
            background: success.main,
            border: `${borderWidth[1]} solid ${success.main}`,
            borderRadius: borderRadius.md,
            color: white.main,
          })}
        />
      ),
      employed: (
        <VuiTypography variant="caption" color="white" fontWeight="medium">
          23/04/18
        </VuiTypography>
      ),
      action: (
        <VuiTypography component="a" href="#" variant="caption" color="text" fontWeight="medium">
          Edit
        </VuiTypography>
      ),
    },
    {
      author: <Author image={avatar2} name="Alexa Liras" email="alexa@simmmple.com" />,
      function: <Function job="Programator" org="Developer" />,
      status: (
        <VuiBadge
          variant="standard"
          badgeContent="Offline"
          size="xs"
          container
          sx={({ palette: { white }, borders: { borderRadius, borderWidth } }) => ({
            background: "unset",
            border: `${borderWidth[1]} solid ${white.main}`,
            borderRadius: borderRadius.md,
            color: white.main,
          })}
        />
      ),
      employed: (
        <VuiTypography variant="caption" color="white" fontWeight="medium">
          11/01/19
        </VuiTypography>
      ),
      action: (
        <VuiTypography component="a" href="#" variant="caption" color="text" fontWeight="medium">
          Edit
        </VuiTypography>
      ),
    },
    {
      author: <Author image={avatar3} name="Laurent Michael" email="laurent@simmmple.com" />,
      function: <Function job="Executive" org="Projects" />,
      status: (
        <VuiBadge
          variant="standard"
          badgeContent="Online"
          color="success"
          size="xs"
          container
          sx={({ palette: { white, success }, borders: { borderRadius, borderWidth } }) => ({
            background: success.main,
            border: `${borderWidth[1]} solid ${success.main}`,
            borderRadius: borderRadius.md,
            color: white.main,
          })}
        />
      ),
      employed: (
        <VuiTypography variant="caption" color="white" fontWeight="medium">
          19/09/17
        </VuiTypography>
      ),
      action: (
        <VuiTypography component="a" href="#" variant="caption" color="text" fontWeight="medium">
          Edit
        </VuiTypography>
      ),
    },
    {
      author: <Author image={avatar1} name="Freduardo Hill" email="freduardo@simmmple.com" />,
      function: <Function job="Programator" org="Developer" />,
      status: (
        <VuiBadge
          variant="standard"
          badgeContent="Online"
          color="success"
          size="xs"
          container
          sx={({ palette: { white, success }, borders: { borderRadius, borderWidth } }) => ({
            background: success.main,
            border: `${borderWidth[1]} solid ${success.main}`,
            borderRadius: borderRadius.md,
            color: white.main,
          })}
        />
      ),
      employed: (
        <VuiTypography variant="caption" color="white" fontWeight="medium">
          24/12/08
        </VuiTypography>
      ),
      action: (
        <VuiTypography component="a" href="#" variant="caption" color="text" fontWeight="medium">
          Edit
        </VuiTypography>
      ),
    },
    {
      author: <Author image={avatar5} name="Daniel Thomas" email="daniel@simmmple.com" />,
      function: <Function job="Manager" org="Executive" />,
      status: (
        <VuiBadge
          variant="standard"
          badgeContent="Offline"
          size="xs"
          container
          sx={({ palette: { white }, borders: { borderRadius, borderWidth } }) => ({
            background: "unset",
            border: `${borderWidth[1]} solid ${white.main}`,
            borderRadius: borderRadius.md,
            color: white.main,
          })}
        />
      ),
      employed: (
        <VuiTypography variant="caption" color="white" fontWeight="medium">
          04/10/21
        </VuiTypography>
      ),
      action: (
        <VuiTypography component="a" href="#" variant="caption" color="text" fontWeight="medium">
          Edit
        </VuiTypography>
      ),
    },
    {
      author: <Author image={avatar6} name="Mark Wilson" email="mark@simmmple.com" />,
      function: <Function job="Programtor" org="Developer" />,
      status: (
        <VuiBadge
          variant="standard"
          badgeContent="Offline"
          size="xs"
          container
          sx={({ palette: { white }, borders: { borderRadius, borderWidth } }) => ({
            background: "unset",
            border: `${borderWidth[1]} solid ${white.main}`,
            borderRadius: borderRadius.md,
            color: white.main,
          })}
        />
      ),
      employed: (
        <VuiTypography variant="caption" color="white" fontWeight="medium">
          14/09/20
        </VuiTypography>
      ),
      action: (
        <VuiTypography component="a" href="#" variant="caption" color="text" fontWeight="medium">
          Edit
        </VuiTypography>
      ),
    },
  ],
};

*/

//  Dashboard React components
import VuiBox from "components/VuiBox";
import VuiTypography from "components/VuiTypography";
import VuiBadge from "components/VuiBadge";

const data = [
    {
        "id": 1,
        "instalacion": "Barcel",
        "fecha_hora": "2024-10-07T20:09:22.004812Z",
        "ubicacion": "A11",
        "transaccion": "ING",
        "codigo_articulo": "papas-01",
        "descripcion_articulo": "Papas Chips Jalapeno 250",
        "cantidad": 110,
        "usuario": "montaCargas-01"
    },
    {
        "id": 2,
        "instalacion": "Barcel",
        "fecha_hora": "2024-10-07T20:10:28.469872Z",
        "ubicacion": "A12",
        "transaccion": "ING",
        "codigo_articulo": "papas-02",
        "descripcion_articulo": "Papas Chips Morada 250",
        "cantidad": 110,
        "usuario": "montaCargas-02"
    },
    {
        "id": 3,
        "instalacion": "Barcel",
        "fecha_hora": "2024-10-07T20:11:19.816056Z",
        "ubicacion": "A11",
        "transaccion": "RET",
        "codigo_articulo": "papas-01",
        "descripcion_articulo": "Papas Chips Jalapeno 250",
        "cantidad": 60,
        "usuario": "montaCargas-03"
    },
    {
        "id": 4,
        "instalacion": "Barcel",
        "fecha_hora": "2024-10-08T04:01:06.968133Z",
        "ubicacion": "A11",
        "transaccion": "RET",
        "codigo_articulo": "papas-01",
        "descripcion_articulo": "Papas Chips Jalapeno 250",
        "cantidad": 60,
        "usuario": "montaCargas-03"
    }
];

export default {
  columns: [
    { name: "id", align: "left" },
    { name: "instalacion", align: "left" },
    { name: "fecha_hora", align: "left" },
    { name: "ubicacion", align: "left" },
    { name: "transaccion", align: "center" },
    { name: "codigo_articulo", align: "left" },
    { name: "descripcion_articulo", align: "left" },
    { name: "cantidad", align: "center" },
    { name: "usuario", align: "left" },
    { name: "action", align: "center" },
  ],

  rows: data.map(item => ({
    id: (
      <VuiTypography variant="caption" color="white" fontWeight="medium">
        {item.id}
      </VuiTypography>
    ),
    instalacion: (
      <VuiTypography variant="caption" color="white" fontWeight="medium">
        {item.instalacion}
      </VuiTypography>
    ),
    fecha_hora: (
      <VuiTypography variant="caption" color="white" fontWeight="medium">
        {new Date(item.fecha_hora).toLocaleString()}
      </VuiTypography>
    ),
    ubicacion: (
      <VuiTypography variant="caption" color="white" fontWeight="medium">
        {item.ubicacion}
      </VuiTypography>
    ),
    transaccion: (
      <VuiBadge
        variant="standard"
        badgeContent={item.transaccion}
        color={item.transaccion === "ING" ? "success" : "error"}
        size="xs"
      />
    ),
    codigo_articulo: (
      <VuiTypography variant="caption" color="white" fontWeight="medium">
        {item.codigo_articulo}
      </VuiTypography>
    ),
    descripcion_articulo: (
      <VuiTypography variant="caption" color="white" fontWeight="medium">
        {item.descripcion_articulo}
      </VuiTypography>
    ),
    cantidad: (
      <VuiTypography variant="caption" color="white" fontWeight="medium">
        {item.cantidad}
      </VuiTypography>
    ),
    usuario: (
      <VuiTypography variant="caption" color="white" fontWeight="medium">
        {item.usuario}
      </VuiTypography>
    ),
    action: (
      <VuiTypography component="a" href="#" variant="caption" color="text" fontWeight="medium">
        Editar
      </VuiTypography>
    ),
  })),
};
