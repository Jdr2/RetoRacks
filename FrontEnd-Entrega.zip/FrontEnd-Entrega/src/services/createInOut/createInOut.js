import Cookies from 'js-cookie';
import axios from 'axios';

export const createInOut = async (data) => {

  const csrftoken = Cookies.get('csrftoken');
  const response = await axios.post('https://back.controldeinventario.info/api/transacciones/crear/', data, {
    headers: {
      'Content-Type': 'application/json',
      Accept: 'application/json',
      'X-CSRFToken': csrftoken,
      "Authorization": `Bearer ${csrftoken}`,
      'Referrer-Policy': 'no-referrer',
    },
    withCredentials: true,
  });
  return response.data;
};

/*
import axios from 'axios';

export const createInOut = async (data) => {
  const accessToken = localStorage.getItem('accessToken'); // Obtén el token de acceso almacenado

  const response = await axios.post('http://be-warehouse-906571168583.us-central1.run.app/api/transacciones/crear/', 
    data, 
    {
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${accessToken}`, // Incluye el token de acceso aquí
      },
    }
  );

  return response.data;
};

*/





// services/createInOut/createInOut.js

/*
import axios from 'axios';

// Función para obtener el token CSRF desde las cookies
function getCSRFToken() {
  let cookieValue = null;
  if (document.cookie && document.cookie !== '') {
    const cookies = document.cookie.split(';');
    for (let i = 0; i < cookies.length; i++) {
      const cookie = cookies[i].trim();
      // ¿Este es el cookie que queremos?
      if (cookie.substring(0, 10) === 'csrftoken=') {
        cookieValue = decodeURIComponent(cookie.substring(10));
        break;
      }
    }
  }
  return cookieValue;
}

export const createInOut = async (data) => {
  const csrfToken = getCSRFToken();
  const response = await axios.post('http://34.66.210.36/api/transacciones/crear/', data, {
    headers: {
      'Content-Type': 'application/json',
      'X-CSRFToken': csrfToken, // Incluir el token CSRF en los encabezados
    },
    withCredentials: true, // Asegurarse de que las cookies se envíen con la solicitud
  });
  return response.data;
};

*/