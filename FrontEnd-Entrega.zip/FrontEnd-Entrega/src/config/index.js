const Config = {
    API_URL: 'https://back.controldeinventario.info/api/',
    BACK_END_URL: 'https://back.controldeinventario.info/',
}

export default Config;