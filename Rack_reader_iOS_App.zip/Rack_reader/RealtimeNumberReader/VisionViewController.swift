// VisionViewController.swift

import Foundation
import UIKit
import AVFoundation
import Vision

class VisionViewController: ViewController {
    var request: VNRecognizeTextRequest!
    // Umbral mínimo para el tamaño del bounding box en píxeles
    let minimumBoundingBoxSize: CGFloat = 100  // Ajusta este valor según tus necesidades

    // Rastreador temporal de cadenas
    let numberTracker = StringTracker()

    override func viewDidLoad() {
        super.viewDidLoad()
        // Configurar la solicitud de Vision antes de que ViewController configure la cámara
        // para que exista cuando se reciba el primer buffer.
        request = VNRecognizeTextRequest(completionHandler: recognizeTextHandler)
    }

    // MARK: - Reconocimiento de texto

    func recognizeTextHandler(request: VNRequest, error: Error?) {
        var numbers = [String]()
        var redBoxes = [CGRect]()   // Muestra todas las líneas de texto reconocidas.
        var greenBoxes = [CGRect]() // Muestra las palabras que podrían ser números de serie.

        guard let results = request.results as? [VNRecognizedTextObservation] else {
            return
        }

        let maximumCandidates = 1

        for visionResult in results {
            guard let candidate = visionResult.topCandidates(maximumCandidates).first else { continue }

            // Obtener el bounding box de la observación
            let boundingBox = visionResult.boundingBox

            // Calcular el tamaño del bounding box en píxeles (en función del tamaño de la vista previa)
            let width = boundingBox.width * previewView.frame.width
            let height = boundingBox.height * previewView.frame.height

            // Si el tamaño del bounding box es menor que el umbral, lo ignoramos
            if width < minimumBoundingBoxSize || height < minimumBoundingBoxSize {
                continue
            }

            var numberIsSubstring = true

            // Intentar detectar si el texto es un número
            if let result = candidate.string.extractPhoneNumber() {
                let (range, number) = result
                // Si el número está dentro de un texto más grande, ajustamos el bounding box
                if let box = try? candidate.boundingBox(for: range)?.boundingBox {
                    numbers.append(number)
                    greenBoxes.append(box)
                    numberIsSubstring = !(range.lowerBound == candidate.string.startIndex && range.upperBound == candidate.string.endIndex)
                }
            }

            // Si no es un número, dibujamos un cuadro rojo alrededor del texto detectado
            if numberIsSubstring {
                redBoxes.append(visionResult.boundingBox)
            }
        }

        // Registrar los números encontrados
        numberTracker.logFrame(strings: numbers)
        show(boxGroups: [(color: .red, boxes: redBoxes), (color: .green, boxes: greenBoxes)])

        // Verificar si hay algún número estable temporalmente
        if let sureNumber = numberTracker.getStableString() {
            showString(string: sureNumber)
            numberTracker.reset(string: sureNumber)
        }
    }

    override func captureOutput(_ output: AVCaptureOutput, didOutput sampleBuffer: CMSampleBuffer, from connection: AVCaptureConnection) {
        if let pixelBuffer = CMSampleBufferGetImageBuffer(sampleBuffer) {
            // Configurar para ejecutar en tiempo real.
            request.recognitionLevel = .accurate
            // La corrección de lenguaje no ayuda en el reconocimiento y ralentiza el proceso.
            request.usesLanguageCorrection = false
            // Ejecutar solo en la región de interés para máxima velocidad.
            request.regionOfInterest = regionOfInterest

            let requestHandler = VNImageRequestHandler(cvPixelBuffer: pixelBuffer, orientation: textOrientation, options: [:])
            do {
                try requestHandler.perform([request])
            } catch {
                print(error)
            }
        }
    }

    // MARK: - Dibujo de bounding boxes

    // Dibujar un cuadro en la pantalla, debe hacerse en el hilo principal.
    var boxLayer = [CAShapeLayer]()
    func draw(rect: CGRect, color: CGColor) {
        let layer = CAShapeLayer()
        layer.opacity = 0.5
        layer.borderColor = color
        layer.borderWidth = 1
        layer.frame = rect
        boxLayer.append(layer)
        previewView.videoPreviewLayer.insertSublayer(layer, at: 1)
    }

    // Remover todos los cuadros dibujados. Debe llamarse en el hilo principal.
    func removeBoxes() {
        for layer in boxLayer {
            layer.removeFromSuperlayer()
        }
        boxLayer.removeAll()
    }

    typealias ColoredBoxGroup = (color: UIColor, boxes: [CGRect])

    // Dibujar grupos de cajas coloreadas.
    func show(boxGroups: [ColoredBoxGroup]) {
        DispatchQueue.main.async {
            let layer = self.previewView.videoPreviewLayer
            self.removeBoxes()
            for boxGroup in boxGroups {
                let color = boxGroup.color
                for box in boxGroup.boxes {
                    let rect = layer.layerRectConverted(fromMetadataOutputRect: box.applying(self.visionToAVFTransform))
                    self.draw(rect: rect, color: color.cgColor)
                }
            }
        }
    }
}
