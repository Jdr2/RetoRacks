//
//  WebSocketManagerServant.swift
//  RealtimeNumberReader
//
//  Created by Cristobal on 23/11/2024.
//  Copyright © 2024 Apple. All rights reserved.
//

import Foundation
import Starscream

class WebSocketManager: WebSocketDelegate {
    
    var socket: WebSocket!
    
    init() {
        // Crear la URL de tu servidor WebSocket de Django
        guard let url = URL(string: "ws://192.168.1.65:8000/ws/ubicacion/") else {
            print("URL inválida")
            return
        }
        
        // Crear una solicitud URLRequest
        var request = URLRequest(url: url)
        request.timeoutInterval = 5  // Tiempo de espera para la conexión, opcional
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")  // Ejemplo de añadir encabezado

        // Inicializar el WebSocket con la solicitud
        socket = WebSocket(request: request)
        
        // Establecer el delegado para manejar los eventos del WebSocket
        socket.delegate = self
        
        // Conectar el WebSocket
        socket.connect()
    }

    // Método para manejar eventos de WebSocket
    func didReceive(event: WebSocketEvent, client: WebSocketClient) {
        switch event {
        case .connected(let headers):
            print("Conectado: \(headers)")  // Puedes procesar los headers si es necesario
        case .disconnected(let reason, let code):
            print("Desconectado: \(reason), código: \(code)")
        case .text(let string):
            print("Mensaje recibido: \(string)")
            // Aquí puedes procesar los mensajes recibidos (como la ubicación planeada)
            if let data = string.data(using: .utf8) {
                do {
                    let jsonResponse = try JSONSerialization.jsonObject(with: data, options: []) as? [String: Any]
                    if let ubicacionPlaneada = jsonResponse?["ubicacion_planeada"] as? String {
                        print("Ubicación Planeada: \(ubicacionPlaneada)")
                        // Aquí puedes actualizar la UI o hacer algo con la ubicación planeada
                    } else if let error = jsonResponse?["error"] as? String {
                        print("Error: \(error)")  // Si hay un error (como "Transacción no encontrada")
                    }
                } catch {
                    print("Error al parsear la respuesta: \(error)")
                }
            }
        case .binary(let data):
            print("Datos binarios recibidos: \(data)")
            // Si tienes datos binarios que manejar, lo haces aquí
        case .pong:
            print("Pong recibido")
        case .ping:
            print("Ping recibido")
        case .error(let error):
            print("Error de WebSocket: \(String(describing: error))")
        case .viabilityChanged(let viable):
            print("Viabilidad cambiada: \(viable ? "Sí" : "No")")
        case .reconnectSuggested(let reason):
            print("Reconexión sugerida: \(reason)")
        case .cancelled:
            print("Conexión WebSocket cancelada")
        case .peerClosed:
            print("El peer (servidor) cerró la conexión")
        }
    }

    // Método para enviar datos al servidor
    func enviarDatosAlServidor(lpn: Int) {
        let message: [String: Any] = [
            "lpn": lpn,
        ]
        
        do {
            let data = try JSONSerialization.data(withJSONObject: message, options: [])
            if let jsonString = String(data: data, encoding: .utf8) {
                socket.write(string: jsonString)  // Asegúrate de enviar como string
            }
        } catch {
            print("Error al enviar datos: \(error)")
        }
    }

    func websocketDidConnect(socket: WebSocketClient) {
        print("Conexión WebSocket establecida")
    }

    func websocketDidDisconnect(socket: WebSocketClient, error: Error?) {
        if let error = error {
            print("Error de conexión: \(error)")
        } else {
            print("Desconectado correctamente")
        }
    }

    func websocketDidReceiveData(socket: WebSocketClient, data: Data) {
        // Manejo de datos binarios si es necesario
        print("Datos binarios recibidos: \(data)")
    }
}
