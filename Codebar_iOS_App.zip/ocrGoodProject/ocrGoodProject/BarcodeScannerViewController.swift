import UIKit
import AVFoundation
import Starscream

class BarcodeScannerViewController: UIViewController, AVCaptureMetadataOutputObjectsDelegate {

    var captureSession: AVCaptureSession!
    var previewLayer: AVCaptureVideoPreviewLayer!
    
    // Instanciamos WebSocketManager para utilizarlo en este controlador
    var webSocketManager: WebSocketManager?

    override func viewDidLoad() {
        super.viewDidLoad()

        // Inicializar WebSocketManager
        webSocketManager = WebSocketManager()
        
        // Configurar la sesión de captura de la cámara
        captureSession = AVCaptureSession()

        guard let videoCaptureDevice = AVCaptureDevice.default(for: .video) else { return }
        let videoDeviceInput: AVCaptureDeviceInput

        do {
            videoDeviceInput = try AVCaptureDeviceInput(device: videoCaptureDevice)
        } catch {
            return
        }

        if (captureSession.canAddInput(videoDeviceInput)) {
            captureSession.addInput(videoDeviceInput)
        } else {
            return
        }

        let metadataOutput = AVCaptureMetadataOutput()
        if (captureSession.canAddOutput(metadataOutput)) {
            captureSession.addOutput(metadataOutput)
            metadataOutput.setMetadataObjectsDelegate(self, queue: DispatchQueue.main)
            metadataOutput.metadataObjectTypes = [.code128]
        } else {
            return
        }

        previewLayer = AVCaptureVideoPreviewLayer(session: captureSession)
        previewLayer.frame = view.layer.bounds
        previewLayer.videoGravity = .resizeAspectFill
        view.layer.addSublayer(previewLayer)

        DispatchQueue.global(qos: .userInitiated).async {
            self.captureSession.startRunning()
        }
    }

    // Delegate method to handle detected barcodes
    func metadataOutput(_ output: AVCaptureMetadataOutput, didOutput metadataObjects: [AVMetadataObject], from connection: AVCaptureConnection) {
        if let metadataObject = metadataObjects.first {
            guard let readableObject = metadataObject as? AVMetadataMachineReadableCodeObject else { return }
            guard let stringValue = readableObject.stringValue else { return }
            AudioServicesPlaySystemSound(SystemSoundID(kSystemSoundID_Vibrate)) // Vibrar al detectar un código

            foundBarcode(stringValue)
        }
    }

    // Método que maneja el código de barras detectado
    func foundBarcode(_ barcode: String) {
           // Intentar convertir la cadena a un número
           if let lpn = Int(barcode) {
               // Si la conversión es exitosa, significa que la cadena es numérica
               print("Código de barras válido: \(barcode)")

               // Detener la sesión de captura (si es necesario)
               captureSession.stopRunning()

               // Enviar el código de barras al servidor WebSocket
               webSocketManager?.enviarDatosAlServidor(lpn: lpn)

               // Mostrar el resultado en una alerta
               let alert = UIAlertController(title: "Código detectado", message: barcode, preferredStyle: .alert)
               alert.addAction(UIAlertAction(title: "Cerrar", style: .default))
               self.present(alert, animated: true)
           } else {
               // Si no se puede convertir el código a número, se ignora o maneja como error
               print("Código de barras ignorado (no es numérico): \(barcode)")
           }
    }

    // Función para detener la captura si es necesario
    func stopScanning() {
        captureSession.stopRunning()
    }
}
